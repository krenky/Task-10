﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_10
{
    class Queue<T>
    {
        int Head = -1;
        int Tail = -1;
        public int Count;
        T[] queue = new T[5];
        public bool isEmpty()
        {
            return Head == Tail;
        }
        public bool isFull()
        {
            if ((Head == Tail + 1) || (Head == 0 && Tail == Count - 1))
            {
                return true;
            }
            return false;
        }
        public bool Push(T Obj)
        {
            if (!isFull())
            {
                if (Head == -1) Head = 0;
                Tail = (Tail + 1) % Count;
                queue[Tail] = Obj;
                return true;
            }
            return false;
        }
        public string Print(int Index)
        {
            if(queue[Index] != null || Index == -1)
            {
                return queue[Index].ToString();
            }
            return "Null";
        }
        public int Search(T Obj)
        {
            for(int i = 0; i<queue.Length; i++)
            {
                if(queue[i].ToString() == Obj.ToString())
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
