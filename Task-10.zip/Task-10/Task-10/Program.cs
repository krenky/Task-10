﻿using System;

namespace Task_10
{
    class Program
    {
        static void Main(string[] args)
        {
            QueueString queueString;
            QueueInt queueInt;
            QueueChar queueChar;
            while (true)
            {
                Console.WriteLine("Add string");
                Console.WriteLine("Add int");
                Console.WriteLine("Add char");
                Console.WriteLine("search string");
                Console.WriteLine("search int");
                Console.WriteLine("search char");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        queueString.Add(Console.ReadLine());
                        break;
                    case 2:

                        break;
                    case 3:

                        break;
                    case 4:

                        break;
                    case 5:

                        break;
                    case 6:

                        break;
                }
            }

        }
        class QueueString
        {
            Queue<string> queue;
            public void Add(string Item)
            {
                queue.Push(Item);
            }
            public string Print(string Item)
            {
                return queue.Print(queue.Search(Item));
            }
        }
        class QueueInt
        {
            Queue<int> queue;
            public void Add(int Item)
            {
                queue.Push(Item);
            }
            public string Print(int Item)
            {
                return queue.Print(queue.Search(Item));
            }
        }
        class QueueChar
        {
            Queue<char> queue;
            public void Add(char Item)
            {
                queue.Push(Item);
            }
            public string Print(char Item)
            {
                return queue.Print(queue.Search(Item));
            }
        }
    }
}
